---
name: Solar CSV analysis constraints
description: Product requirements for truthful, private solar production analysis.
---

The solar analyzer must show no sample or synthetic data before a CSV is uploaded. Analyze only the user's uploaded CSV in memory; do not persist uploads or add authentication, a database, or third-party APIs. Keep the application in Python Streamlit with only Streamlit, pandas, Plotly, and NumPy as direct app libraries.

The daytime filter currently means 06:00–17:59. Keep that exact range visible wherever the daytime option is described.

**Why:** The user explicitly requested real uploaded data only, no permanent file storage, and no external services. They requested a daytime filter without specifying hours, so the current interface uses a clear fixed window.

**How to apply:** Preserve the privacy and real-data constraints when changing the upload flow or analysis screens. If changing the daytime window, update both the filter logic and its explanatory text.
