from __future__ import annotations

import io
import re
import unicodedata
from datetime import datetime
from html import escape as html_escape

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st


st.set_page_config(
    page_title="태양광 발전량 분석",
    page_icon="",
    layout="wide",
)


FIELD_LABELS = {
    "date": "날짜",
    "time": "시간 (선택)",
    "generator": "발전기",
    "generation": "계량전력량 (kWh)",
    "temperature": "기온 (°C)",
    "irradiance": "일사량 (MJ/m²)",
}

ALIASES = {
    "date": [
        "날짜",
        "일자",
        "측정일",
        "기록일",
        "발전일자",
        "date",
        "datetime",
        "timestamp",
        "측정시간",
        "수집일시",
        "일시",
    ],
    "time": ["시간", "시각", "측정시각", "time", "hour"],
    "generator": [
        "발전기",
        "발전기명",
        "발전기번호",
        "발전기id",
        "generator",
        "generatorname",
        "generatorid",
        "설비명",
        "장비명",
        "인버터",
        "인버터명",
        "inverter",
        "invertername",
    ],
    "generation": [
        "발전량",
        "발전전력량",
        "일발전량",
        "발전량kwh",
        "발전량kw h",
        "전력량",
        "발전에너지",
        "generation",
        "energy",
        "energykwh",
        "production",
        "solarproduction",
        "outputkwh",
        "kwh",
    ],
    "temperature": [
        "기온",
        "평균기온",
        "온도",
        "temperature",
        "airtemperature",
        "airtemp",
        "temp",
    ],
    "irradiance": [
        "일사",
        "일사량",
        "평균일사",
        "일사량mj",
        "일사량mj/m2",
        "irradiance",
        "solarradiation",
        "radiation",
        "insolation",
        "ghi",
        "mj/m2",
    ],
}

REQUIRED_FIELDS = ("date", "generator", "generation", "temperature", "irradiance")
NUMERIC_FIELDS = ("generation", "temperature", "irradiance")
ENCODINGS = ("utf-8-sig", "utf-8", "cp949")


def normalize_header(value: object) -> str:
    normalized = unicodedata.normalize("NFKC", str(value)).casefold()
    return re.sub(r"[\W_]+", "", normalized, flags=re.UNICODE)


def guess_column(field: str, columns: list[str]) -> str | None:
    normalized_aliases = [normalize_header(alias) for alias in ALIASES[field]]
    normalized_columns = [(column, normalize_header(column)) for column in columns]

    for alias in normalized_aliases:
        for column, normalized in normalized_columns:
            if normalized == alias:
                return column

    # A descriptive header such as "기상 관측 일사량(MJ/m²)" can still match.
    for alias in normalized_aliases:
        if len(alias) < 2:
            continue
        for column, normalized in normalized_columns:
            if alias in normalized:
                return column
    return None


def read_uploaded_csv(uploaded_file: st.runtime.uploaded_file_manager.UploadedFile):
    """Read the uploaded bytes in memory; never write the file to disk."""
    raw_bytes = uploaded_file.getvalue()
    if not raw_bytes or not raw_bytes.strip():
        raise ValueError("파일에 읽을 수 있는 내용이 없습니다. 데이터가 있는 CSV를 업로드해 주세요.")

    decode_errors: list[str] = []
    for encoding in ENCODINGS:
        try:
            text = raw_bytes.decode(encoding)
        except UnicodeDecodeError:
            decode_errors.append(encoding)
            continue

        try:
            return pd.read_csv(io.StringIO(text)), encoding
        except pd.errors.EmptyDataError as exc:
            raise ValueError("CSV에 헤더나 데이터가 없습니다. 내용이 있는 파일을 업로드해 주세요.") from exc
        except pd.errors.ParserError as exc:
            raise ValueError(
                "CSV 형식을 읽지 못했습니다. 각 행의 열 개수가 같은지 확인해 주세요."
            ) from exc

    raise ValueError(
        "파일 인코딩을 확인할 수 없습니다. UTF-8-SIG, UTF-8 또는 CP949 형식의 CSV를 업로드해 주세요."
    )


def convert_numeric(series: pd.Series) -> tuple[pd.Series, int, list[str]]:
    original_text = series.astype("string").str.strip()
    nonempty = series.notna() & original_text.ne("")
    cleaned = original_text.str.replace(",", "", regex=False)
    converted = pd.to_numeric(cleaned, errors="coerce")

    values = converted.to_numpy(dtype=float, na_value=np.nan)
    non_finite = pd.Series(np.isinf(values), index=series.index)
    failed = nonempty & (converted.isna() | non_finite)
    converted = converted.mask(non_finite)
    examples = original_text.loc[failed].dropna().drop_duplicates().head(3).tolist()
    return converted, int(failed.sum()), examples


def normalize_value_text(series: pd.Series) -> pd.Series:
    normalized = series.astype("string").map(
        lambda value: unicodedata.normalize("NFKC", value) if pd.notna(value) else pd.NA
    )
    return normalized.astype("string").str.strip()


def parse_date_values(series: pd.Series) -> pd.Series:
    text = normalize_value_text(series)
    text = text.str.replace(
        r"(\d{4})\s*년\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일?",
        r"\1-\2-\3",
        regex=True,
    )
    text = text.str.replace(
        r"^(\d{4})\s*[./]\s*(\d{1,2})\s*[./]\s*(\d{1,2})\.?(\s.*)?$",
        r"\1-\2-\3\4",
        regex=True,
    )
    text = text.str.replace(r"^(\d{8})\.0+$", r"\1", regex=True)

    parsed = pd.to_datetime(text, format="mixed", errors="coerce")
    compact_date = text.str.fullmatch(r"\d{8}", na=False)
    compact_parsed = pd.to_datetime(
        text.where(compact_date),
        format="%Y%m%d",
        errors="coerce",
    )
    parsed = parsed.fillna(compact_parsed)

    numeric = pd.to_numeric(text, errors="coerce")
    excel_serial = (numeric.ge(20000) & numeric.le(100000)).fillna(False)
    serial_dates = pd.to_datetime(
        numeric.where(excel_serial),
        unit="D",
        origin="1899-12-30",
        errors="coerce",
    )
    parsed = parsed.mask(excel_serial, serial_dates)
    return parsed.fillna(serial_dates)


def parse_time_values(series: pd.Series) -> pd.Series:
    text = normalize_value_text(series).str.casefold()
    text = (
        text.str.replace("오전", "am", regex=False)
        .str.replace("오후", "pm", regex=False)
        .str.replace(r"\s*시\s*", ":", regex=True)
        .str.replace(r"\s*분\s*", ":", regex=True)
        .str.replace(r"\s*초\s*", "", regex=True)
        .str.rstrip(":")
        .str.strip()
    )
    result = pd.Series(pd.NaT, index=series.index, dtype="timedelta64[ns]")

    numeric = pd.to_numeric(text, errors="coerce")
    excel_fraction = (numeric.ge(0) & numeric.lt(1)).fillna(False)
    result.loc[excel_fraction] = pd.to_timedelta(
        numeric.loc[excel_fraction],
        unit="D",
    )
    numeric_hour = (numeric.ge(1) & numeric.le(24)).fillna(False)
    result.loc[numeric_hour] = pd.to_timedelta(
        numeric.loc[numeric_hour],
        unit="h",
    )

    am_pm_parts = text.str.extract(
        r"^(am|pm)\s*(\d{1,2})(?::(\d{1,2}))?(?::(\d{1,2}))?$"
    )
    am_pm_hour = pd.to_numeric(am_pm_parts[1], errors="coerce")
    am_pm_minute = pd.to_numeric(am_pm_parts[2].fillna("0"), errors="coerce")
    am_pm_second = pd.to_numeric(am_pm_parts[3].fillna("0"), errors="coerce")
    is_pm = am_pm_parts[0].eq("pm")
    am_pm_valid = (
        am_pm_hour.between(1, 12)
        & am_pm_minute.between(0, 59)
        & am_pm_second.between(0, 59)
    ).fillna(False)
    converted_hour = (am_pm_hour % 12) + is_pm.astype("Int64").fillna(0) * 12
    am_pm_seconds = converted_hour * 3600 + am_pm_minute * 60 + am_pm_second
    result.loc[am_pm_valid] = pd.to_timedelta(
        am_pm_seconds.loc[am_pm_valid],
        unit="s",
    )

    compact_time = text.str.extract(r"^(\d{1,2})(\d{2})$")
    compact_hour = pd.to_numeric(compact_time[0], errors="coerce")
    compact_minute = pd.to_numeric(compact_time[1], errors="coerce")
    compact_valid = (
        compact_hour.between(0, 24)
        & compact_minute.between(0, 59)
        & ~((compact_hour == 24) & (compact_minute != 0))
    ).fillna(False)
    compact_seconds = compact_hour * 3600 + compact_minute * 60
    result.loc[compact_valid] = pd.to_timedelta(
        compact_seconds.loc[compact_valid],
        unit="s",
    )

    clock_parts = text.str.extract(r"^(\d{1,2}):(\d{1,2})(?::(\d{1,2}))?$")
    clock_hour = pd.to_numeric(clock_parts[0], errors="coerce")
    clock_minute = pd.to_numeric(clock_parts[1], errors="coerce")
    clock_second = pd.to_numeric(clock_parts[2].fillna("0"), errors="coerce")
    clock_valid = (
        clock_hour.between(0, 24)
        & clock_minute.between(0, 59)
        & clock_second.between(0, 59)
        & ~(
            (clock_hour == 24)
            & ((clock_minute != 0) | (clock_second != 0))
        )
    ).fillna(False)
    clock_seconds = clock_hour * 3600 + clock_minute * 60 + clock_second
    result.loc[clock_valid] = pd.to_timedelta(
        clock_seconds.loc[clock_valid],
        unit="s",
    )

    # A time column may itself contain a full timestamp; retain only its clock part.
    full_timestamp = pd.to_datetime(text, format="mixed", errors="coerce")
    full_time = full_timestamp - full_timestamp.dt.normalize()
    return result.fillna(full_time)


def has_nonblank_values(series: pd.Series) -> pd.Series:
    text = normalize_value_text(series)
    return series.notna() & text.ne("").fillna(False)


def format_number(value: float, decimals: int = 2) -> str:
    return f"{value:,.{decimals}f}"


st.title("태양광 발전량 분석")
st.write(
    "발전기별 계량전력량과 기상 데이터가 담긴 CSV를 업로드하면 필터에 따른 지표와 추이를 확인할 수 있습니다."
)
st.caption("업로드한 파일은 메모리에서만 처리하며 서버에 파일로 저장하지 않습니다.")

uploaded_file = st.file_uploader(
    "분석할 CSV 파일을 업로드하세요",
    type=["csv"],
    help="UTF-8-SIG, UTF-8, CP949 인코딩을 차례로 확인합니다.",
)

if uploaded_file is None:
    st.info(
        "시작하려면 CSV 파일을 업로드하세요. 날짜와 시간, 발전기, 계량전력량(kWh), "
        "기온(°C), 일사량(MJ/m²) 컬럼을 매핑해 분석할 수 있습니다."
    )
    st.stop()

try:
    raw_data, detected_encoding = read_uploaded_csv(uploaded_file)
except ValueError as error:
    st.error(str(error))
    st.stop()
except (OSError, UnicodeError, pd.errors.ParserError) as error:
    st.error("CSV 파일을 읽지 못했습니다. 파일이 손상되지 않았는지 확인해 주세요.")
    st.caption(str(error))
    st.stop()

st.subheader("업로드 데이터")
st.write(f"행 수: **{len(raw_data):,}** · 컬럼 수: **{len(raw_data.columns):,}**")
st.caption(f"확인된 인코딩: {detected_encoding}")

if len(raw_data.columns) == 0:
    st.error("CSV에서 컬럼명을 찾지 못했습니다. 첫 번째 줄에 컬럼명이 있는지 확인해 주세요.")
    st.stop()

st.write("컬럼명")
st.code(", ".join(str(column) for column in raw_data.columns), language=None)

preview_column, missing_column = st.columns(2)
with preview_column:
    st.markdown("**업로드 원본 미리보기 (분석 필터 적용 전)**")
    st.dataframe(raw_data.head(10), use_container_width=True, hide_index=True)
    st.caption("이 표는 업로드 확인용입니다. 분석 표·KPI·그래프는 아래의 필터 결과를 사용합니다.")
with missing_column:
    st.markdown("**컬럼별 결측치 개수**")
    missing_summary = pd.DataFrame(
        {
            "컬럼명": [str(column) for column in raw_data.columns],
            "결측치 개수": raw_data.isna().sum().astype(int).to_list(),
        }
    )
    st.dataframe(missing_summary, use_container_width=True, hide_index=True)

if raw_data.empty:
    st.error("헤더는 있지만 데이터 행이 없습니다. 데이터가 포함된 CSV를 업로드해 주세요.")
    st.stop()

columns = [str(column) for column in raw_data.columns]
st.subheader("컬럼 매핑")
st.write("자동 제안을 확인하고 날짜, 시간, 발전기, 계량전력량, 기온, 일사량 컬럼을 맞춰 주세요.")
selected_columns: dict[str, str | None] = {}
for field_group in (
    ("date", "time", "generator"),
    ("generation", "temperature", "irradiance"),
):
    field_columns = st.columns(3)
    for position, field in enumerate(field_group):
        suggested = guess_column(field, columns)
        placeholder = "선택 안 함" if field == "time" else "선택하세요"
        options = [placeholder] + columns
        default_index = options.index(suggested) if suggested in columns else 0
        with field_columns[position]:
            selected = st.selectbox(
                FIELD_LABELS[field],
                options,
                index=default_index,
                key=f"mapping_{field}",
                help=(
                    "날짜 컬럼에 날짜와 시간이 함께 있으면 비워 두세요."
                    if field == "time"
                    else None
                ),
            )
        selected_columns[field] = None if selected == placeholder else selected

missing_fields = [
    FIELD_LABELS[field]
    for field in REQUIRED_FIELDS
    if selected_columns[field] is None
]
if missing_fields:
    st.error(
        "필수 컬럼 매핑이 필요합니다: "
        + ", ".join(missing_fields)
        + ". 각 항목에 해당하는 CSV 컬럼을 선택해 주세요."
    )
    st.stop()

required_selection = [selected_columns[field] for field in REQUIRED_FIELDS]
if len(set(required_selection)) != len(required_selection):
    st.error("날짜, 발전기, 계량전력량, 기온, 일사량은 서로 다른 컬럼으로 선택해 주세요.")
    st.stop()

if (
    selected_columns["time"] is not None
    and selected_columns["time"] != selected_columns["date"]
    and selected_columns["time"] in required_selection
):
    st.error("시간 컬럼은 날짜·발전기·계량전력량·기온·일사량 컬럼과 다르게 선택해 주세요.")
    st.stop()

date_values = raw_data[selected_columns["date"]]
parsed_dates = parse_date_values(date_values)
date_nonblank = has_nonblank_values(date_values)

separate_time_column = (
    selected_columns["time"] is not None
    and selected_columns["time"] != selected_columns["date"]
)
if separate_time_column:
    time_values = raw_data[selected_columns["time"]]
    parsed_times = parse_time_values(time_values)
    time_nonblank = has_nonblank_values(time_values)
    embedded_date_time = parsed_dates.notna() & parsed_dates.ne(parsed_dates.dt.normalize())
    analysis_timestamps = parsed_dates.dt.normalize() + parsed_times
    analysis_timestamps = analysis_timestamps.where(
        parsed_times.notna(),
        parsed_dates.where(embedded_date_time),
    )
    has_time_information = bool(parsed_times.notna().any() or embedded_date_time.any())
else:
    time_values = None
    time_nonblank = pd.Series(False, index=raw_data.index)
    analysis_timestamps = parsed_dates
    embedded_date_time = parsed_dates.notna() & parsed_dates.ne(parsed_dates.dt.normalize())
    date_text = normalize_value_text(date_values)
    explicit_clock = date_text.str.contains(
        r"(?:T|\s)\d{1,2}:\d{2}", regex=True, na=False
    )
    date_numeric = pd.to_numeric(date_text, errors="coerce")
    excel_fractional_clock = (
        date_numeric.notna() & date_numeric.mod(1).ne(0) & date_numeric.between(1, 100000)
    )
    has_time_information = bool(
        embedded_date_time.any() or explicit_clock.any() or excel_fractional_clock.any()
    )

invalid_datetime_mask = (
    (date_nonblank | time_nonblank) & analysis_timestamps.isna()
)
invalid_dates = int(invalid_datetime_mask.sum())
if invalid_dates:
    st.warning(
        f"날짜·시간을 분석용 일시로 변환하지 못한 행이 {invalid_dates:,}개 있습니다. "
        "변환할 수 없는 행만 분석에서 제외됩니다."
    )
    source_datetime_columns = [selected_columns["date"]]
    if separate_time_column:
        source_datetime_columns.append(selected_columns["time"])
    with st.expander("변환 실패 원본값 예시 보기", expanded=False):
        st.caption("아래 값은 업로드된 CSV의 실제 원본값입니다. 파일로 저장하지 않습니다.")
        st.dataframe(
            raw_data.loc[invalid_datetime_mask, source_datetime_columns].head(10),
            use_container_width=True,
            hide_index=True,
        )

if not has_time_information:
    st.error(
        "시간대별 그래프와 주간 필터를 위해 시간 정보가 필요합니다. "
        "시간 컬럼을 선택하거나 날짜 컬럼에 날짜와 시간이 함께 들어 있는지 확인해 주세요."
    )
    st.stop()

numeric_values: dict[str, pd.Series] = {}
conversion_failures: dict[str, tuple[int, list[str]]] = {}
for field in NUMERIC_FIELDS:
    converted, failure_count, examples = convert_numeric(raw_data[selected_columns[field]])
    numeric_values[field] = converted
    conversion_failures[field] = (failure_count, examples)

if any(count for count, _ in conversion_failures.values()):
    st.warning("숫자로 변환할 수 없는 값은 결측으로 처리하고 분석에서 제외합니다.")
    for field, (count, examples) in conversion_failures.items():
        if count:
            detail = f"{FIELD_LABELS[field]}: {count:,}개"
            if examples:
                detail += f" (예: {', '.join(examples)})"
            st.write(f"- {detail}")

generator_values = raw_data[selected_columns["generator"]].astype("string").str.strip()
generator_values = generator_values.replace("", pd.NA)
analysis_data = pd.DataFrame(
    {
        "분석용 일시": analysis_timestamps,
        "발전기": generator_values,
        "계량전력량 (kWh)": numeric_values["generation"],
        "기온 (°C)": numeric_values["temperature"],
        "일사량 (MJ/m²)": numeric_values["irradiance"],
    }
)
analysis_columns = [
    "분석용 일시",
    "발전기",
    "계량전력량 (kWh)",
    "기온 (°C)",
    "일사량 (MJ/m²)",
]

# Remove exact duplicates only across the selected analysis fields.
duplicate_mask = analysis_data.duplicated(subset=analysis_columns, keep="first")
duplicate_rows_removed = int(duplicate_mask.sum())
deduplicated_data = analysis_data.loc[~duplicate_mask].copy()

missing_cells = deduplicated_data[analysis_columns].isna().sum()
missing_rows_mask = deduplicated_data[analysis_columns].isna().any(axis=1)
missing_rows_removed = int(missing_rows_mask.sum())
clean_data = deduplicated_data.loc[~missing_rows_mask].copy()

st.subheader("결측치·중복 처리 내역")
st.caption(
    "중복은 선택한 일시·발전기·계량전력량·기온·일사량 값이 모두 같은 행으로 판단해 첫 행만 남깁니다. "
    "필수 분석값이 비었거나 변환되지 않은 행은 제외합니다."
)
processing_columns = st.columns(4)
processing_columns[0].metric("업로드 행", f"{len(raw_data):,}")
processing_columns[1].metric("중복 제거", f"{duplicate_rows_removed:,}")
processing_columns[2].metric("결측·변환 오류 제외", f"{missing_rows_removed:,}")
processing_columns[3].metric("분석 가능 행", f"{len(clean_data):,}")

missing_analysis_summary = pd.DataFrame(
    {
        "분석 컬럼": analysis_columns,
        "결측·변환 실패 셀 수": [int(missing_cells[column]) for column in analysis_columns],
    }
)
st.dataframe(missing_analysis_summary, use_container_width=True, hide_index=True)

if clean_data.empty:
    st.error(
        "결측치와 변환 오류를 제외한 뒤 분석할 행이 없습니다. 날짜·시간, 발전기, "
        "계량전력량, 기온, 일사량 컬럼의 값을 확인해 주세요."
    )
    st.stop()

minimum_date = clean_data["분석용 일시"].min().date()
maximum_date = clean_data["분석용 일시"].max().date()
generator_options = sorted(clean_data["발전기"].unique().tolist(), key=str.casefold)
temperature_min = float(clean_data["기온 (°C)"].min())
temperature_max = float(clean_data["기온 (°C)"].max())

st.sidebar.header("분석 필터")
st.sidebar.caption("필터는 모든 KPI, 그래프, 분석 데이터 표, 다운로드에 동일하게 적용됩니다.")
selected_dates = st.sidebar.date_input(
    "기간",
    value=(minimum_date, maximum_date),
    min_value=minimum_date,
    max_value=maximum_date,
)
if isinstance(selected_dates, (tuple, list)):
    if len(selected_dates) == 2 and selected_dates[0] and selected_dates[1]:
        start_date, end_date = selected_dates
    elif len(selected_dates) == 1 and selected_dates[0]:
        start_date = end_date = selected_dates[0]
    else:
        start_date, end_date = minimum_date, maximum_date
else:
    start_date = end_date = selected_dates

selected_generators = st.sidebar.multiselect(
    "발전기",
    options=generator_options,
    default=generator_options,
)
time_filter = st.sidebar.radio(
    "시간대",
    options=["전체", "주간 (06:00–18:00)"],
    index=0,
    help="주간은 분석용 일시의 시각이 06:00 이상 18:00 미만인 행입니다.",
)

if temperature_min < temperature_max:
    temperature_span = temperature_max - temperature_min
    temperature_step = max(temperature_span / 100, 0.000001)
    selected_temperature_range = st.sidebar.slider(
        "기온 범위 (°C)",
        min_value=temperature_min,
        max_value=temperature_max,
        value=(temperature_min, temperature_max),
        step=temperature_step,
        format="%.2f",
    )
else:
    selected_temperature_range = (temperature_min, temperature_max)
    st.sidebar.caption(f"기온 범위: {format_number(temperature_min)} °C (변동 없음)")

filtered_mask = (
    clean_data["분석용 일시"].dt.date.ge(start_date)
    & clean_data["분석용 일시"].dt.date.le(end_date)
    & clean_data["발전기"].isin(selected_generators)
    & clean_data["기온 (°C)"].between(
        selected_temperature_range[0], selected_temperature_range[1]
    )
)
if time_filter == "주간 (06:00–18:00)":
    filtered_mask &= clean_data["분석용 일시"].dt.hour.between(6, 17)
filtered_data = clean_data.loc[filtered_mask].copy()

st.subheader("처리 및 분석 대상 행")
st.metric("현재 필터 분석 행", f"{len(filtered_data):,}")
st.caption(
    f"분석 가능 행 {len(clean_data):,}개 중 필터 적용 후 {len(filtered_data):,}개를 분석합니다. "
    "결측·중복 처리 수치는 기간 및 필터 적용 전 전체 업로드 기준입니다."
)

if filtered_data.empty:
    st.info("선택한 필터에 해당하는 데이터가 없습니다. 기간이나 필터 조건을 조정해 주세요.")
    st.stop()

st.subheader("분석 요약")
kpi_columns = st.columns(4)
kpi_columns[0].metric(
    "계량전력량 합계",
    f"{format_number(float(filtered_data['계량전력량 (kWh)'].sum()))} kWh",
)
kpi_columns[1].metric(
    "평균 기온",
    f"{format_number(float(filtered_data['기온 (°C)'].mean()))} °C",
)
kpi_columns[2].metric(
    "평균 일사량",
    f"{format_number(float(filtered_data['일사량 (MJ/m²)'].mean()))} MJ/m²",
)
kpi_columns[3].metric("분석 대상 행 수", f"{len(filtered_data):,}")

st.subheader("일자별 계량전력량 합계")
daily_data = (
    filtered_data.assign(일자=filtered_data["분석용 일시"].dt.floor("D"))
    .groupby("일자", as_index=False)["계량전력량 (kWh)"]
    .sum()
    .sort_values("일자")
)
daily_chart = px.line(
    daily_data,
    x="일자",
    y="계량전력량 (kWh)",
    markers=True,
    labels={
        "일자": "일자",
        "계량전력량 (kWh)": "일자별 계량전력량 합계 (kWh)",
    },
)
daily_chart.update_layout(
    height=360,
    margin=dict(l=12, r=12, t=18, b=12),
    hovermode="x unified",
    yaxis_title="일자별 합계 (kWh)",
)
st.plotly_chart(daily_chart, use_container_width=True)
st.caption(
    "집계 기준: 필터 적용 후 날짜별 합계이며, 선택한 발전기가 여러 대이면 발전기 간 합산합니다. 단위: kWh/일."
)

st.subheader("시간대별 평균 계량전력량")
hourly_data = (
    filtered_data.assign(시간대=filtered_data["분석용 일시"].dt.hour)
    .groupby("시간대", as_index=False)
    .agg(
        **{
            "평균 계량전력량 (kWh)": ("계량전력량 (kWh)", "mean"),
            "관측 행 수": ("계량전력량 (kWh)", "size"),
        }
    )
    .sort_values("시간대")
)
hourly_chart = px.bar(
    hourly_data,
    x="시간대",
    y="평균 계량전력량 (kWh)",
    hover_data=["관측 행 수"],
    labels={
        "시간대": "시간 (0–23시)",
        "평균 계량전력량 (kWh)": "시간대별 평균 계량전력량 (kWh)",
    },
)
hourly_chart.update_layout(
    height=360,
    margin=dict(l=12, r=12, t=18, b=12),
    xaxis=dict(dtick=1),
    yaxis_title="관측 행 단위 평균 (kWh)",
)
st.plotly_chart(hourly_chart, use_container_width=True)
st.caption(
    "집계 기준: 필터 적용 후 같은 시각에 기록된 행들의 산술 평균입니다. 단위: kWh/행."
)

st.subheader("일사량과 계량전력량")
st.info(
    "주간과 야간 데이터가 함께 포함되면 발전량이 0에 가까운 야간 값이 상관관계에 영향을 줄 수 있습니다. "
    "주간 필터 결과와 비교해 해석해 주세요."
)
correlation_pairs = filtered_data[
    ["일사량 (MJ/m²)", "계량전력량 (kWh)"]
].replace([np.inf, -np.inf], np.nan).dropna()
scatter_chart = px.scatter(
    correlation_pairs,
    x="일사량 (MJ/m²)",
    y="계량전력량 (kWh)",
    labels={
        "일사량 (MJ/m²)": "일사량 (MJ/m²)",
        "계량전력량 (kWh)": "계량전력량 (kWh)",
    },
    color_discrete_sequence=["#d99512"],
)
scatter_chart.update_layout(
    height=360,
    margin=dict(l=12, r=12, t=18, b=12),
    xaxis_title="일사량 (MJ/m²)",
    yaxis_title="계량전력량 (kWh)",
)
st.plotly_chart(scatter_chart, use_container_width=True)

pair_count = len(correlation_pairs)
pearson_r: float | None = None
if pair_count >= 3:
    irradiance_values = correlation_pairs["일사량 (MJ/m²)"].to_numpy(dtype=float)
    energy_values = correlation_pairs["계량전력량 (kWh)"].to_numpy(dtype=float)
    if np.ptp(irradiance_values) > 0 and np.ptp(energy_values) > 0:
        calculated_r = float(np.corrcoef(irradiance_values, energy_values)[0, 1])
        if np.isfinite(calculated_r):
            pearson_r = calculated_r
            st.metric("피어슨 상관계수 r", f"{pearson_r:.3f}")
        else:
            st.info("현재 필터의 데이터로 유효한 상관계수 r을 계산할 수 없습니다.")
    else:
        st.info(
            f"유효 짝 데이터는 {pair_count:,}개지만, 일사량과 계량전력량 모두에 변동이 있어야 "
            "상관계수 r을 계산할 수 있습니다."
        )
else:
    st.info(
        f"유효 짝 데이터가 {pair_count:,}개입니다. 상관계수 r은 유효 짝이 3개 이상이고 "
        "두 변수 모두에 변동이 있을 때만 계산합니다."
    )
st.caption(
    f"산점도 단위: x축 MJ/m², y축 kWh. 상관계수 계산에 사용 가능한 짝 데이터: {pair_count:,}개."
)

st.subheader("필터 적용 분석 데이터")
st.dataframe(
    filtered_data[analysis_columns],
    use_container_width=True,
    hide_index=True,
)
download_data = filtered_data[analysis_columns].to_csv(index=False).encode("utf-8-sig")
st.download_button(
    "필터 결과 CSV 다운로드",
    data=download_data,
    file_name="solar_analysis_filtered.csv",
    mime="text/csv",
)

st.subheader("분석 보고서 다운로드")
st.caption(
    "보고서는 현재 필터 결과에서 계산한 요약 통계와 해석 한계만 포함합니다. "
    "업로드한 CSV의 전체 행은 보고서에 넣지 않습니다."
)

total_energy_kwh = float(filtered_data["계량전력량 (kWh)"].sum())
average_temperature = float(filtered_data["기온 (°C)"].mean())
average_irradiance = float(filtered_data["일사량 (MJ/m²)"].mean())
available_period = (
    f"{clean_data['분석용 일시'].min():%Y-%m-%d} ~ "
    f"{clean_data['분석용 일시'].max():%Y-%m-%d}"
)
filtered_period = (
    f"{filtered_data['분석용 일시'].min():%Y-%m-%d %H:%M} ~ "
    f"{filtered_data['분석용 일시'].max():%Y-%m-%d %H:%M}"
)
generator_filter = (
    f"전체 ({len(generator_options):,}개)"
    if set(selected_generators) == set(generator_options)
    else ", ".join(str(generator) for generator in selected_generators)
)
temperature_filter = (
    f"{format_number(float(selected_temperature_range[0]))} ~ "
    f"{format_number(float(selected_temperature_range[1]))} °C"
)
created_at = datetime.now().astimezone().isoformat(timespec="seconds")

daily_energy = daily_data["계량전력량 (kWh)"]
daily_peak = daily_data.loc[daily_energy.idxmax()]
daily_low = daily_data.loc[daily_energy.idxmin()]
daily_mean = float(daily_energy.mean())
daily_slope = None
if len(daily_data) >= 2:
    days_from_start = (
        daily_data["일자"] - daily_data["일자"].min()
    ).dt.days.to_numpy(dtype=float)
    if np.ptp(days_from_start) > 0:
        daily_slope = float(
            np.polyfit(days_from_start, daily_energy.to_numpy(dtype=float), 1)[0]
        )

hourly_means = hourly_data["평균 계량전력량 (kWh)"]
highest_hour = hourly_data.loc[hourly_means.idxmax()]
lowest_hour = hourly_data.loc[hourly_means.idxmin()]
correlation_summary = (
    f"r = {pearson_r:.3f} (유효 짝 {pair_count:,}개)"
    if pearson_r is not None
    else f"산정 불가 (유효 짝 {pair_count:,}개; 최소 3개와 두 변수의 변동 필요)"
)

daily_findings = [
    f"관측 일자 수: {len(daily_data):,}일",
    (
        f"일별 합계 최대: {daily_peak['일자']:%Y-%m-%d}, "
        f"{format_number(float(daily_peak['계량전력량 (kWh)']))} kWh"
    ),
    (
        f"일별 합계 최소: {daily_low['일자']:%Y-%m-%d}, "
        f"{format_number(float(daily_low['계량전력량 (kWh)']))} kWh"
    ),
    f"관측 일별 합계 평균: {format_number(daily_mean)} kWh/일",
]
if daily_slope is not None:
    daily_findings.append(
        f"일별 합계 선형 추세 기울기: {daily_slope:+.3f} kWh/일 "
        "(양수는 증가 방향, 음수는 감소 방향)"
    )
else:
    daily_findings.append("관측 일자가 1일이므로 일별 추세 기울기는 계산하지 않았습니다.")

hourly_findings = [
    f"관측 시간대 수: {len(hourly_data):,}개",
    (
        f"평균이 가장 높은 시간대: {int(highest_hour['시간대']):02d}시, "
        f"{format_number(float(highest_hour['평균 계량전력량 (kWh)']))} kWh/행 "
        f"(관측 {int(highest_hour['관측 행 수']):,}행)"
    ),
    (
        f"평균이 가장 낮은 시간대: {int(lowest_hour['시간대']):02d}시, "
        f"{format_number(float(lowest_hour['평균 계량전력량 (kWh)']))} kWh/행 "
        f"(관측 {int(lowest_hour['관측 행 수']):,}행)"
    ),
]

filter_rows = [
    ("기간 필터", f"{start_date:%Y-%m-%d} ~ {end_date:%Y-%m-%d}"),
    ("발전기 필터", generator_filter or "선택 없음"),
    ("시간대 필터", time_filter),
    ("기온 필터", temperature_filter),
]
metric_rows = [
    ("총 계량전력량", f"{format_number(total_energy_kwh)} kWh"),
    ("평균 기온", f"{format_number(average_temperature)} °C"),
    ("평균 일사량", f"{format_number(average_irradiance)} MJ/m²"),
    ("분석 데이터 건수", f"{len(filtered_data):,}행"),
    ("일사량-발전량 피어슨 상관계수", correlation_summary),
]
processing_rows = [
    ("업로드 행", f"{len(raw_data):,}"),
    ("중복 제거 행", f"{duplicate_rows_removed:,}"),
    ("결측·변환 오류로 제외된 행", f"{missing_rows_removed:,}"),
    ("현재 필터 분석 행", f"{len(filtered_data):,}"),
    ("날짜·시간 변환 실패 행", f"{invalid_dates:,}"),
]
processing_rows.extend(
    (f"{FIELD_LABELS[field]} 숫자 변환 실패", f"{count:,}")
    for field, (count, _) in conversion_failures.items()
)
missing_cell_rows = [
    (f"{column} 결측 셀", f"{int(missing_cells[column]):,}")
    for column in analysis_columns
]

plain_text_rows = lambda rows: "\n".join(f"- {label}: {value}" for label, value in rows)
plain_text_list = lambda items: "\n".join(f"- {item}" for item in items)
html_table_rows = lambda rows: "".join(
    f"<tr><th>{html_escape(str(label))}</th><td>{html_escape(str(value))}</td></tr>"
    for label, value in rows
)
html_list_items = lambda items: "".join(
    f"<li>{html_escape(str(item))}</li>" for item in items
)

report_file_name = str(uploaded_file.name).replace("\r", " ").replace("\n", " ")
text_report = "\n".join(
    [
        "태양광 발전량 분석 보고서",
        f"생성 시각: {created_at}",
        f"업로드 파일명: {report_file_name}",
        f"유효 데이터 기준 기간: {available_period}",
        f"현재 필터 데이터 실제 기간: {filtered_period}",
        "",
        "[현재 필터 조건]",
        plain_text_rows(filter_rows),
        "",
        "[핵심 지표]",
        plain_text_rows(metric_rows),
        "",
        "[일별 추세 요약]",
        plain_text_list(daily_findings),
        "",
        "[시간대별 특징]",
        plain_text_list(hourly_findings),
        "",
        "[데이터 처리 및 결측]",
        plain_text_rows(processing_rows),
        plain_text_rows(missing_cell_rows),
        "",
        "[해석 한계]",
        "- 통계는 현재 필터가 적용된 유효 행만 사용하며, 중복 및 결측·변환 오류 행은 분석에서 제외합니다.",
        "- 분석 범위는 업로드 CSV에 포함된 유효 기간에 한정되며, 업로드되지 않은 기간은 반영하지 않습니다.",
        "- 피어슨 r은 두 변수의 선형 상관관계이며 인과관계를 의미하지 않습니다.",
        "- 주간과 야간 데이터가 섞이면 시간대 차이가 상관계수에 영향을 줄 수 있습니다.",
        "- 일별 합계는 선택한 발전기의 행을 날짜별로 합산하고, 시간대별 값은 관측 행별 산술 평균으로 계산합니다.",
        "- 이 보고서에는 원본 CSV 전체 행이 포함되지 않고 요약 통계만 포함됩니다.",
    ]
)

html_report = f"""<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>태양광 발전량 분석 보고서</title>
  <style>
    body {{ max-width: 900px; margin: 40px auto; padding: 0 20px; color: #202938; font: 16px/1.6 system-ui, sans-serif; }}
    h1 {{ margin-bottom: 4px; }} h2 {{ margin-top: 32px; border-bottom: 1px solid #d7dde5; padding-bottom: 6px; }}
    table {{ width: 100%; border-collapse: collapse; }} th, td {{ text-align: left; padding: 9px 10px; border-bottom: 1px solid #e6e9ee; }}
    th {{ width: 34%; color: #475467; }} .meta {{ color: #667085; font-size: 14px; }}
    .note {{ background: #f4f7fb; padding: 14px 18px; border-radius: 8px; }}
  </style>
</head>
<body>
  <h1>태양광 발전량 분석 보고서</h1>
  <p class="meta">생성 시각: {html_escape(created_at)}<br>
  업로드 파일명: {html_escape(report_file_name)}<br>
  유효 데이터 기준 기간: {html_escape(available_period)}<br>
  현재 필터 데이터 실제 기간: {html_escape(filtered_period)}</p>

  <h2>현재 필터 조건</h2>
  <table><tbody>{html_table_rows(filter_rows)}</tbody></table>

  <h2>핵심 지표</h2>
  <table><tbody>{html_table_rows(metric_rows)}</tbody></table>

  <h2>일별 추세 요약</h2>
  <ul>{html_list_items(daily_findings)}</ul>

  <h2>시간대별 특징</h2>
  <ul>{html_list_items(hourly_findings)}</ul>

  <h2>데이터 처리 및 결측</h2>
  <table><tbody>{html_table_rows(processing_rows + missing_cell_rows)}</tbody></table>

  <h2>해석 한계</h2>
  <ul>
    <li>통계는 현재 필터가 적용된 유효 행만 사용하며, 중복 및 결측·변환 오류 행은 분석에서 제외합니다.</li>
    <li>분석 범위는 업로드 CSV에 포함된 유효 기간에 한정되며, 업로드되지 않은 기간은 반영하지 않습니다.</li>
    <li>피어슨 r은 두 변수의 선형 상관관계이며 인과관계를 의미하지 않습니다.</li>
    <li>주간과 야간 데이터가 섞이면 시간대 차이가 상관계수에 영향을 줄 수 있습니다.</li>
    <li>일별 합계는 선택한 발전기의 행을 날짜별로 합산하고, 시간대별 값은 관측 행별 산술 평균으로 계산합니다.</li>
    <li>이 보고서에는 원본 CSV 전체 행이 포함되지 않고 요약 통계만 포함됩니다.</li>
  </ul>
  <p class="note">일별 합계와 시간대별 평균은 모두 현재 필터 결과에서 계산했습니다.</p>
</body>
</html>
"""

report_columns = st.columns(2)
with report_columns[0]:
    st.download_button(
        "HTML 보고서 다운로드",
        data=html_report.encode("utf-8"),
        file_name="solar_analysis_report.html",
        mime="text/html; charset=utf-8",
        use_container_width=True,
    )
with report_columns[1]:
    st.download_button(
        "TXT 보고서 다운로드",
        data=text_report.encode("utf-8"),
        file_name="solar_analysis_report.txt",
        mime="text/plain; charset=utf-8",
        use_container_width=True,
    )
